import os
import csv
import json
import numpy as np
from typing import Dict, List, Any
from Code.dataset import load_dataset
from Code.evaluator import compute_res_score
from Code.prompt_llm import Stage1LLMPipeline
from Code.validator import validate_report_structure, validate_clinical_fidelity

def create_stratified_folds(dataset: List[Dict[str, str]], num_folds: int = 5) -> List[List[int]]:
    """Create 5-fold splits stratified by modality + body_part."""
    strata = {}
    for idx, case in enumerate(dataset):
        key = f"{case.get('modality', '')}_{case.get('body_part', '')}"
        strata.setdefault(key, []).append(idx)

    folds = [[] for _ in range(num_folds)]
    for key, indices in strata.items():
        for i, idx in enumerate(indices):
            folds[i % num_folds].append(idx)
            
    return folds


def run_stage1_cross_validation(train_path: str = "train.csv", max_cases: int = None) -> Dict[str, float]:
    """
    Runs 5-fold cross-validation of Stage 1 on train.csv and computes average RES scores.
    """
    print("=" * 60)
    print("RUNNING STAGE 1 CROSS-VALIDATION EVALUATION")
    print("=" * 60)

    dataset = load_dataset(train_path)
    if max_cases:
        dataset = dataset[:max_cases]

    folds = create_stratified_folds(dataset, num_folds=5)
    pipeline = Stage1LLMPipeline()

    all_res_scores = []
    all_findings_scores = []
    all_impression_scores = []
    validation_failures = 0

    total_cases = len(dataset)

    for fold_idx, val_indices in enumerate(folds):
        fold_res = []
        fold_findings = []
        fold_impression = []

        print(f"\nEvaluating Fold {fold_idx + 1}/5 ({len(val_indices)} cases)...")
        
        for case_idx in val_indices:
            case = dataset[case_idx]
            ref_report = case.get('report', '')
            tmpl_content = case.get('template_content', '')

            # Generate Stage 1 report
            pred_report, _ = pipeline.process_case(case)

            # Structural validation check
            is_valid, struct_issues = validate_report_structure(pred_report, tmpl_content)
            if not is_valid:
                validation_failures += 1

            # RES metric calculation
            scores = compute_res_score(ref_report, pred_report, tmpl_content)

            fold_res.append(scores['res_case'])
            fold_findings.append(scores['findings_score'])
            fold_impression.append(scores['impression_score'])

        mean_fold_res = float(np.mean(fold_res))
        mean_fold_f = float(np.mean(fold_findings))
        mean_fold_i = float(np.mean(fold_impression))

        print(f"Fold {fold_idx + 1} RES: {mean_fold_res:.4f} | FINDINGS: {mean_fold_f:.4f} | IMPRESSION: {mean_fold_i:.4f}")

        all_res_scores.extend(fold_res)
        all_findings_scores.extend(fold_findings)
        all_impression_scores.extend(fold_impression)

    overall_res = float(np.mean(all_res_scores))
    overall_f = float(np.mean(all_findings_scores))
    overall_i = float(np.mean(all_impression_scores))

    print("\n" + "=" * 60)
    print("STAGE 1 CROSS-VALIDATION SUMMARY RESULTS")
    print("=" * 60)
    print(f"Total Cases Evaluated: {total_cases}")
    print(f"Mean Leaderboard RES Score : {overall_res:.4f} (Lower is better)")
    print(f"Mean FINDINGS Edit Score F : {overall_f:.4f}")
    print(f"Mean IMPRESSION Edit Score I: {overall_i:.4f}")
    print(f"Structural Validation Failures: {validation_failures}")
    print("=" * 60)

    summary = {
        'overall_res': overall_res,
        'overall_findings': overall_f,
        'overall_impression': overall_i,
        'validation_failures': validation_failures,
        'total_cases': total_cases
    }

    # Save summary
    os.makedirs("outputs", exist_ok=True)
    with open("outputs/stage1_cv_results.json", "w") as f:
        json.dump(summary, f, indent=2)

    return summary


def generate_submission(test_path: str = "test.csv", output_csv: str = "submission.csv"):
    """
    Generates submission.csv for test.csv cases.
    """
    print("\n" + "=" * 60)
    print("GENERATING STAGE 1 SUBMISSION CSV FOR TEST DATASET")
    print("=" * 60)

    test_cases = load_dataset(test_path)
    pipeline = Stage1LLMPipeline()

    submission_rows = []
    validation_issues_count = 0

    for idx, case in enumerate(test_cases):
        case_id = case['case_id']
        pred_report, _ = pipeline.process_case(case)

        # Validate report
        is_valid, issues = validate_report_structure(pred_report, case.get('template_content', ''))
        if not is_valid:
            validation_issues_count += 1

        submission_rows.append({
            'case_id': case_id,
            'report': pred_report
        })

    # Write submission.csv cleanly using csv.DictWriter with utf-8
    with open(output_csv, 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['case_id', 'report'])
        writer.writeheader()
        writer.writerows(submission_rows)

    print(f"Successfully generated '{output_csv}' with {len(submission_rows)} rows.")
    print(f"Validation warning count: {validation_issues_count}")
    print("=" * 60)


if __name__ == "__main__":
    cv_res = run_stage1_cross_validation()
    generate_submission()
